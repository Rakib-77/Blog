(function($) {
	'use strict';

	$('.menu-icon i').on('click', function() {
		$('.main-menu > ul').slideToggle();
	});

}) (jQuery);